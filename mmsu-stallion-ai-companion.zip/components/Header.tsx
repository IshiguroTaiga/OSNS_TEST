
import React, { useState } from 'react';
import { College } from '../types';
import { COLLEGES } from '../constants';

interface HeaderProps {
  userCollege: College;
  onCollegeChange: (college: College) => void;
  onOpenSettings: () => void;
  isDark: boolean;
  toggleTheme: () => void;
}

export const Header: React.FC<HeaderProps> = ({ 
  userCollege, 
  onCollegeChange, 
  onOpenSettings,
  isDark,
  toggleTheme
}) => {
  const [showDocs, setShowDocs] = useState(false);
  const [activeDocTab, setActiveDocTab] = useState<'specs' | 'diagrams'>('specs');

  return (
    <header className={`${isDark ? 'bg-mmsu-darkGreen' : 'bg-mmsu-green'} text-white sticky top-0 z-50 shadow-lg border-b border-mmsu-gold/30`}>
      <div className="max-w-7xl mx-auto px-4 py-3 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 bg-mmsu-gold rounded-full flex items-center justify-center text-mmsu-green font-bold text-2xl shadow-inner border-2 border-white/20">
            <i className="fas fa-horse"></i>
          </div>
          <div className="flex flex-col">
            <h1 className="font-extrabold text-xl tracking-tight leading-none uppercase">MMSU Stallion</h1>
            <p className="text-[10px] text-mmsu-gold uppercase tracking-[0.2em] font-bold">Academic Companion</p>
          </div>
        </div>
        
        <div className="flex items-center space-x-4 w-full md:w-auto">
          <div className="flex-1 md:flex-none">
            <label className="text-[10px] text-mmsu-gold uppercase font-bold block mb-1">Select College</label>
            <select 
              value={userCollege}
              onChange={(e) => onCollegeChange(e.target.value as College)}
              className={`text-xs p-2 rounded-lg border-none focus:ring-2 focus:ring-mmsu-gold w-full transition-colors ${
                isDark ? 'bg-black/40 text-white' : 'bg-white/10 text-white'
              }`}
            >
              {COLLEGES.map(c => (
                <option key={c} value={c} className="text-gray-900">{c}</option>
              ))}
            </select>
          </div>
          
          <div className="flex items-center space-x-2">
            <button 
              onClick={() => setShowDocs(true)}
              className="p-2.5 rounded-full hover:bg-white/10 transition-colors text-mmsu-gold"
              title="Project Documentation"
            >
              <i className="fas fa-file-invoice text-lg"></i>
            </button>
            <button 
              onClick={toggleTheme}
              className="p-2.5 rounded-full hover:bg-white/10 transition-colors"
              title="Toggle Theme"
            >
              <i className={`fas ${isDark ? 'fa-sun' : 'fa-moon'} text-lg`}></i>
            </button>
            <button 
              onClick={onOpenSettings}
              className="w-10 h-10 rounded-full border-2 border-mmsu-gold/50 hover:border-mmsu-gold transition-all flex items-center justify-center bg-white/10"
              title="Student Profile"
            >
              <i className="fas fa-user text-sm"></i>
            </button>
          </div>
        </div>
      </div>

      {showDocs && (
        <div className="fixed inset-0 bg-black/80 z-[200] flex items-center justify-center p-4 backdrop-blur-md animate-fadeIn">
          <div className={`rounded-[2.5rem] w-full max-w-4xl max-h-[90vh] shadow-2xl overflow-hidden border flex flex-col ${
            isDark ? 'bg-gray-900 border-gray-700 text-white' : 'bg-white border-white text-gray-900'
          }`}>
            <div className="bg-mmsu-green p-6 text-white relative flex-shrink-0">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-2xl font-black">Technical Documentation</h3>
                  <p className="text-xs text-mmsu-gold font-bold uppercase tracking-widest">Formal Specifications v2.0</p>
                </div>
                <button 
                  onClick={() => setShowDocs(false)}
                  className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
                >
                  <i className="fas fa-times"></i>
                </button>
              </div>
              
              <div className="flex space-x-4 border-b border-white/10">
                <button 
                  onClick={() => setActiveDocTab('specs')}
                  className={`pb-2 text-xs font-black uppercase tracking-widest border-b-2 transition-all ${
                    activeDocTab === 'specs' ? 'border-mmsu-gold text-mmsu-gold' : 'border-transparent text-white/50'
                  }`}
                >
                  Use Cases & NFRs
                </button>
                <button 
                  onClick={() => setActiveDocTab('diagrams')}
                  className={`pb-2 text-xs font-black uppercase tracking-widest border-b-2 transition-all ${
                    activeDocTab === 'diagrams' ? 'border-mmsu-gold text-mmsu-gold' : 'border-transparent text-white/50'
                  }`}
                >
                  System Diagrams
                </button>
              </div>
            </div>
            
            <div className="flex-1 overflow-y-auto p-8 space-y-12">
              {activeDocTab === 'specs' ? (
                <>
                  <section className="space-y-4">
                    <div className="flex items-center space-x-3">
                       <div className="w-8 h-8 bg-mmsu-gold rounded-lg flex items-center justify-center text-mmsu-green font-black text-xs">01</div>
                       <h4 className="text-mmsu-green dark:text-mmsu-gold font-black uppercase tracking-widest text-sm">Use Case: Digital Profile Management</h4>
                    </div>
                    <div className={`p-6 rounded-3xl border ${isDark ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'}`}>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
                        <div className="space-y-3">
                          <p><span className="font-black text-mmsu-green dark:text-mmsu-gold uppercase">Description:</span> Persists student identity and college context for platform personalization.</p>
                          <p><span className="font-black text-mmsu-green dark:text-mmsu-gold uppercase">Alternative Flow:</span> Student skip profile setup; system defaults to "Stallion Guest".</p>
                          <p><span className="font-black text-mmsu-green dark:text-mmsu-gold uppercase">Exception Flow:</span> Invalid Student ID format (not YY-XXXXXX); system blocks tutoring activation.</p>
                        </div>
                        <div className="space-y-3">
                          <p><span className="font-black text-mmsu-green dark:text-mmsu-gold uppercase">Pre-condition:</span> User accesses Settings menu.</p>
                          <p><span className="font-black text-mmsu-green dark:text-mmsu-gold uppercase">Post-condition:</span> Preferences persisted in LocalStorage for session persistence.</p>
                        </div>
                      </div>
                    </div>
                  </section>

                  <section className="space-y-4">
                    <div className="flex items-center space-x-3">
                       <div className="w-8 h-8 bg-mmsu-gold rounded-lg flex items-center justify-center text-mmsu-green font-black text-xs">02</div>
                       <h4 className="text-mmsu-green dark:text-mmsu-gold font-black uppercase tracking-widest text-sm">Use Case: Verified AI Tutoring</h4>
                    </div>
                    <div className={`p-6 rounded-3xl border ${isDark ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'}`}>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
                        <div className="space-y-3">
                          <p><span className="font-black text-mmsu-green dark:text-mmsu-gold uppercase">Description:</span> Real-time academic query resolution grounded in Google Search results.</p>
                          <p><span className="font-black text-mmsu-green dark:text-mmsu-gold uppercase">Alternative Flow:</span> User switches to "General Mode"; academic strictness protocols are relaxed.</p>
                          <p><span className="font-black text-mmsu-green dark:text-mmsu-gold uppercase">Exception Flow:</span> API failure; system provides emergency contact info for College Registrar.</p>
                        </div>
                        <div className="space-y-3">
                          <p><span className="font-black text-mmsu-green dark:text-mmsu-gold uppercase">Pre-condition:</span> Valid Student ID verification.</p>
                          <p><span className="font-black text-mmsu-green dark:text-mmsu-gold uppercase">Post-condition:</span> AI response rendered with verified source link cards.</p>
                        </div>
                      </div>
                    </div>
                  </section>

                  <section className="space-y-6">
                    <h4 className="text-mmsu-green dark:text-mmsu-gold font-black uppercase tracking-widest text-xs border-b pb-2 border-mmsu-gold/20">Non-Functional Requirements (NFRs)</h4>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className={`p-5 rounded-2xl border ${isDark ? 'bg-gray-800 border-gray-700' : 'bg-white shadow-sm'}`}>
                        <i className="fas fa-bolt text-mmsu-gold mb-3 text-xl"></i>
                        <h5 className="font-black text-[10px] uppercase mb-2">Performance</h5>
                        <p className="text-[9px] opacity-70 leading-relaxed font-bold tracking-tighter">Response latency &lt; 3s for 95% of queries.</p>
                      </div>
                      <div className={`p-5 rounded-2xl border ${isDark ? 'bg-gray-800 border-gray-700' : 'bg-white shadow-sm'}`}>
                        <i className="fas fa-shield-halved text-blue-500 mb-3 text-xl"></i>
                        <h5 className="font-black text-[10px] uppercase mb-2">Security</h5>
                        <p className="text-[9px] opacity-70 leading-relaxed font-bold tracking-tighter">Zero-Server footprint; student data stays on device.</p>
                      </div>
                      <div className={`p-5 rounded-2xl border ${isDark ? 'bg-gray-800 border-gray-700' : 'bg-white shadow-sm'}`}>
                        <i className="fas fa-universal-access text-purple-500 mb-3 text-xl"></i>
                        <h5 className="font-black text-[10px] uppercase mb-2">Accessibility</h5>
                        <p className="text-[9px] opacity-70 leading-relaxed font-bold tracking-tighter">WCAG AA compliant contrast and mobile responsiveness.</p>
                      </div>
                    </div>
                  </section>
                </>
              ) : (
                <div className="space-y-12">
                  <section className="space-y-4">
                    <h4 className="text-mmsu-green dark:text-mmsu-gold font-black uppercase tracking-widest text-xs border-b pb-2 border-mmsu-gold/20">Package Diagram</h4>
                    <div className={`p-8 rounded-[2rem] border ${isDark ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'}`}>
                      <div className="flex flex-col items-center space-y-6">
                         <div className="grid grid-cols-2 gap-8 w-full">
                           <div className="border-2 border-mmsu-green rounded-xl p-4 text-center">
                              <p className="text-[10px] font-black uppercase text-mmsu-green mb-2">UI Layer</p>
                              <div className="space-y-2">
                                <div className="bg-white dark:bg-gray-700 p-2 text-[8px] font-bold border rounded">components/AIChat</div>
                                <div className="bg-white dark:bg-gray-700 p-2 text-[8px] font-bold border rounded">components/Home</div>
                              </div>
                           </div>
                           <div className="border-2 border-mmsu-gold rounded-xl p-4 text-center">
                              <p className="text-[10px] font-black uppercase text-mmsu-gold mb-2">Service Layer</p>
                              <div className="space-y-2">
                                <div className="bg-white dark:bg-gray-700 p-2 text-[8px] font-bold border rounded">services/gemini.ts</div>
                                <div className="bg-white dark:bg-gray-700 p-2 text-[8px] font-bold border rounded">@google/genai SDK</div>
                              </div>
                           </div>
                           <div className="border-2 border-blue-500 rounded-xl p-4 text-center">
                              <p className="text-[10px] font-black uppercase text-blue-500 mb-2">Data Schema</p>
                              <div className="space-y-2">
                                <div className="bg-white dark:bg-gray-700 p-2 text-[8px] font-bold border rounded">types.ts (Interfaces)</div>
                              </div>
                           </div>
                           <div className="border-2 border-purple-500 rounded-xl p-4 text-center">
                              <p className="text-[10px] font-black uppercase text-purple-500 mb-2">Static Config</p>
                              <div className="space-y-2">
                                <div className="bg-white dark:bg-gray-700 p-2 text-[8px] font-bold border rounded">constants.tsx</div>
                              </div>
                           </div>
                         </div>
                      </div>
                    </div>
                  </section>

                  <section className="space-y-4">
                    <h4 className="text-mmsu-green dark:text-mmsu-gold font-black uppercase tracking-widest text-xs border-b pb-2 border-mmsu-gold/20">Component Diagram</h4>
                    <div className={`p-8 rounded-[2rem] border ${isDark ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'}`}>
                      <div className="flex flex-col items-center">
                        <div className="w-48 p-4 bg-mmsu-green text-white rounded-xl text-center font-black text-xs shadow-lg mb-8">
                          User Interface (App)
                        </div>
                        <i className="fas fa-arrow-down text-gray-400 mb-8"></i>
                        <div className="flex items-center space-x-12">
                          <div className="flex flex-col items-center">
                            <div className="w-36 p-4 bg-mmsu-gold text-mmsu-green rounded-xl text-center font-black text-[10px] shadow-lg">
                              Gemini AI Wrapper
                            </div>
                            <i className="fas fa-sync text-gray-400 my-4"></i>
                            <div className="w-36 p-4 bg-blue-500 text-white rounded-xl text-center font-black text-[10px] shadow-lg">
                              Google Search Tool
                            </div>
                          </div>
                          <div className="h-40 w-px bg-gray-300"></div>
                          <div className="w-36 p-4 bg-gray-200 dark:bg-gray-600 rounded-xl text-center font-black text-[10px] shadow-lg">
                            Browser LocalStorage
                          </div>
                        </div>
                      </div>
                    </div>
                  </section>
                </div>
              )}
            </div>

            <div className="p-8 bg-gray-50 dark:bg-gray-900/30 flex-shrink-0 border-t border-gray-100 dark:border-gray-800">
               <button 
                onClick={() => setShowDocs(false)}
                className="w-full bg-mmsu-green hover:bg-mmsu-darkGreen text-white py-5 rounded-2xl text-xs font-black uppercase tracking-widest transition-all shadow-xl shadow-mmsu-green/20"
              >
                Close Technical Documentation
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
