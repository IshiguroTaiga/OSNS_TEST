
import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Navigation } from './components/Navigation';
import { Home } from './components/Home';
import { AIChat } from './components/AIChat';
import { CourseExplorer } from './components/CourseExplorer';
import { TutorNetwork } from './components/TutorNetwork';
import { UserProfile, College, Campus, ChatMode } from './types';
import { COLLEGES } from './constants';

type Tab = 'chat' | 'courses' | 'tutors' | 'home';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Tab>('home');
  const [chatMode, setChatMode] = useState<ChatMode>('GENERAL');
  const [showSettings, setShowSettings] = useState(false);
  const [user, setUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('mmsu_stallion_user_v2');
    return saved ? JSON.parse(saved) : {
      name: 'Stallion Guest',
      email: '',
      college: 'College of Computing and Information Sciences',
      campus: 'Batac',
      isLoggedIn: false,
      theme: 'light',
      studentId: ''
    };
  });

  useEffect(() => {
    localStorage.setItem('mmsu_stallion_user_v2', JSON.stringify(user));
    if (user.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [user]);

  const toggleTheme = () => {
    setUser(prev => ({ ...prev, theme: prev.theme === 'light' ? 'dark' : 'light' }));
  };

  const handleUpdateUser = (updates: Partial<UserProfile>) => {
    setUser(prev => ({ ...prev, ...updates }));
  };

  const handleCollegeChange = (college: College) => {
    setUser(prev => ({ ...prev, college }));
  };

  const startAiTutoring = () => {
    setChatMode('TUTORING');
    setActiveTab('chat');
  };

  const renderTab = () => {
    switch(activeTab) {
      case 'home': 
        return <Home user={user} onNavigateToChat={() => { setChatMode('GENERAL'); setActiveTab('chat'); }} />;
      case 'chat': 
        return (
          <AIChat 
            college={user.college} 
            studentId={user.studentId} 
            onUpdateStudentId={(id) => handleUpdateUser({ studentId: id })}
            isDark={user.theme === 'dark'}
            mode={chatMode}
            onModeChange={setChatMode}
          />
        );
      case 'courses': 
        return <CourseExplorer selectedCollege={user.college} />;
      case 'tutors': 
        return <TutorNetwork selectedCollege={user.college} onStartAiTutor={startAiTutoring} isDark={user.theme === 'dark'} />;
      default: 
        return <Home user={user} onNavigateToChat={() => { setChatMode('GENERAL'); setActiveTab('chat'); }} />;
    }
  };

  return (
    <div className={`min-h-screen flex flex-col pb-20 md:pb-0 transition-colors duration-300 ${
      user.theme === 'dark' ? 'bg-gray-900 text-white' : 'bg-gray-50 text-gray-900'
    }`}>
      <Header 
        userCollege={user.college} 
        onCollegeChange={handleCollegeChange}
        onOpenSettings={() => setShowSettings(true)}
        isDark={user.theme === 'dark'}
        toggleTheme={toggleTheme}
      />
      
      <div className={`border-b sticky top-[72px] md:top-[72px] z-40 hidden md:block backdrop-blur-md ${
        user.theme === 'dark' ? 'bg-gray-900/80 border-gray-800' : 'bg-white/80 border-gray-100'
      }`}>
        <Navigation activeTab={activeTab} setActiveTab={setActiveTab} />
      </div>

      <main className="flex-1 max-w-7xl mx-auto w-full px-4 py-8 md:py-12">
        {renderTab()}
      </main>

      <div className="md:hidden">
        <Navigation activeTab={activeTab} setActiveTab={setActiveTab} />
      </div>

      {showSettings && (
        <div className="fixed inset-0 bg-black/60 z-[100] flex items-center justify-center p-4 backdrop-blur-md animate-fadeIn">
          <div className={`rounded-[2.5rem] w-full max-w-md shadow-2xl overflow-hidden border ${
            user.theme === 'dark' ? 'bg-gray-800 border-gray-700' : 'bg-white border-white'
          }`}>
            <div className="bg-mmsu-green p-8 text-white relative">
              <h3 className="text-2xl font-black">Student Profile</h3>
              <p className="text-xs text-mmsu-gold mt-1 font-bold uppercase tracking-widest">Digital ID Card</p>
              <button 
                onClick={() => setShowSettings(false)}
                className="absolute right-6 top-6 w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
              >
                <i className="fas fa-times"></i>
              </button>
            </div>
            
            <div className="p-8 space-y-6">
              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest">Full Name</label>
                <input 
                  type="text" 
                  className={`w-full rounded-2xl p-3 text-sm focus:ring-2 focus:ring-mmsu-green border transition-all ${
                    user.theme === 'dark' ? 'bg-gray-900 border-gray-700 text-white' : 'bg-gray-50 border-gray-200 text-gray-900'
                  }`}
                  value={user.name}
                  onChange={(e) => handleUpdateUser({ name: e.target.value })}
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest">Student Number</label>
                <input 
                  type="text" 
                  className={`w-full rounded-2xl p-3 text-sm focus:ring-2 focus:ring-mmsu-green border transition-all ${
                    user.theme === 'dark' ? 'bg-gray-900 border-gray-700 text-white' : 'bg-gray-50 border-gray-200 text-gray-900'
                  }`}
                  value={user.studentId || ''}
                  placeholder="YY-XXXXXX"
                  onChange={(e) => handleUpdateUser({ studentId: e.target.value })}
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest">Official Campus</label>
                <div className="grid grid-cols-2 gap-2">
                  {(['Batac', 'Laoag', 'Currimao', 'Dingras'] as Campus[]).map(c => (
                    <button
                      key={c}
                      onClick={() => handleUpdateUser({ campus: c })}
                      className={`py-3 text-[10px] font-black rounded-2xl border transition-all uppercase tracking-widest ${
                        user.campus === c 
                          ? 'bg-mmsu-green text-white border-mmsu-green shadow-lg shadow-mmsu-green/20' 
                          : user.theme === 'dark' ? 'bg-gray-900 text-gray-400 border-gray-700 hover:border-mmsu-gold' : 'bg-gray-50 text-gray-500 border-gray-200 hover:border-mmsu-green'
                      }`}
                    >
                      {c}
                    </button>
                  ))}
                </div>
              </div>

              <button 
                onClick={() => setShowSettings(false)}
                className="w-full bg-mmsu-green hover:bg-mmsu-darkGreen text-white py-4 rounded-2xl text-xs font-black uppercase tracking-widest transition-all shadow-xl shadow-mmsu-green/20"
              >
                Save Profile
              </button>
            </div>
          </div>
        </div>
      )}

      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: scale(0.95); }
          to { opacity: 1; transform: scale(1); }
        }
        .animate-fadeIn {
          animation: fadeIn 0.3s cubic-bezier(0.4, 0, 0.2, 1) forwards;
        }
      `}</style>
    </div>
  );
};

export default App;
